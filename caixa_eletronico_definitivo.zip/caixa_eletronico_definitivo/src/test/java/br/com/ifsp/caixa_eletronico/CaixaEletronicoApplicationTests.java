package br.com.ifsp.caixa_eletronico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaixaEletronicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
